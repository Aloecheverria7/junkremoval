<section class="default-intro-section" style="background-image:url(img/background/image-1.jpg);">
    	<div class="auto-container">
        	<div class="row clearfix">
                <div class="col-md-10 col-sm-12 col-xs-12 pull-right">
                	<!--Content Box-->
                	<div class="content-box">
                    	<div class="row clearfix">
                        	<div class="col-md-7 col-sm-12">
                                <h3> <?php echo $Phrase[4] ?></h3>
                                
                            </div>
                            <div class="col-md-5 col-sm-12 pull-right"><div class="text-right padd-top-20 wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms"><a href="contact.php" class="theme-btn btn-style-three">Contact us <span class="icon icon-right flaticon-arrows-10"></span></a></div></div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
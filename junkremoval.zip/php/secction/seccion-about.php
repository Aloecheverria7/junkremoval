<div class="about-us-page1-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="about-us-goal">
                    <h2 class="title-bar50"><span class="color">Bienvenidos a </span><br><?php echo $Company;?></h2>
                    <p><?php echo $About[0];?></p>
                    <p><?php echo $Home[1];?></p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
               <div class="about_row hidden-xs">                     
                    <div class="intro_1 intro_img">
                        <div class="box">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>  
                        </div>
                        <img src="img/about/1.jpg" alt="Obten tu mejor opcion en cafe!" loading="lazy">
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div>
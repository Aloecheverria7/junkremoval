
<link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">

<!-- Bootstrap core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

<!--Default CSS-->
<link href="css/default.css" rel="stylesheet" type="text/css">

<!--Custom CSS-->
<link href="css/style.css" rel="stylesheet" type="text/css">

<!--Blog CSS-->
<link href="css/blog.css" rel="stylesheet" type="text/css">

<!--Plugin CSS-->
<link href="css/plugin.css" rel="stylesheet" type="text/css">

<!--Font Awesome-->
<link href="css/font-awesome.css" rel="stylesheet" type="text/css">




    <!--*Scripts*-->

<!-- Latest jquery --><script src="js/jquery-3.2.1.min.js"></script>

<!-- latest Bootstrap --><script src="js/bootstrap.min.js"></script>

<!-- Easing Jquery --><script src="js/jquery.easing.min.js"></script>

<!-- wow animated jquery --><script src="js/wow.min.js"></script>

<!-- Navigation jquery --><script src="js/jquery.nav.js"></script>

<!-- Slick jquery --><script src="js/slick.js"></script>

<!-- Slicknav jquery --><script src="js/slicknav.js"></script>

<!-- custom nav jquery --><script src="js/custom-nav.js"></script>

<!-- Modal Video Jquery --><script src="js/jquery-modal-video.min.js"></script>

<!-- LightBox Jquery --><script src="js/ekko-lightbox.min.js"></script>

<!-- CountTo Jquery --><script src="js/jquery.countTo.js"></script>

<!-- Appear Jquery --><script src="js/jquery.appear.js"></script>

<!-- custom video Jquery --><script src="js/custom-video.js"></script>

<!-- main default Jquery --><script src="js/main.js"></script>
// popupvideo

    jQuery(document).ready(function(){
        jQuery(".js-video-button").modalVideo({channel:'vimeo'});
    });
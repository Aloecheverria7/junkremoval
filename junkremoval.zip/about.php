

<?php include('php/secction/header.php') ?>





<!--Page Title-->
            <section class="page-title" style="background-image:url(img/resource/remodelacion/p_5.jpg);">
                    <div class="auto-container">
                        <h1> <?php echo $About[0] ?> </h1>
                        
                    </div>
                </section>
                
                <!--Breadcrumb-->
                <div class="theme-breadcrumb">
                    <div class="auto-container">
                        <ol class="breadcrumb" style="margin-bottom: 5px;">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">About Us</span></li>
                        </ol>
                    </div>
                </div>
                
                
                <!--Default Two Column-->
                <section class="default-two-column padd-bott-50">
                    <div class="auto-container">
                        <div class="row clearfix">
                            <!--Image COlumn-->
                            <div class="column image-column col-md-6 col-sm-12 col-xs-12">
                                <figure class="imag"><img src="img/resource/about.jpg" alt=""></figure>
                            </div>
                            <!--Text-Column-->
                            <div class="column text-column col-md-6 col-sm-12 col-xs-12">
                                <div class="text padd-left-20 padd-top-50">
                                    <p> <?php echo $About[1] ?> </p>
                                    <p> <?php echo $About[2] ?> </p>
                                    <P> <?PHP ECHO $About[3] ?></P>
                                    <P> <?PHP echo $About[4] ?> </P>
                                </div>
                            </div>
                        </div>
                    </div>
            </section>
            
            
            <!--Services Section-->
                <section class="services-section">
                    <div class="auto-container">
                        <div class="outer-box">
                            <div class="row clearfix">
                                <!--Service Column-->
                                <div class="column service-column col-md-6 col-sm-12 col-xs-12">
                                    <h3> <?php echo $AL[0] ?></h3>
                                    <div class="text"> <?php echo $AD[0] ?> </div>
                                </div>
                                <!--Service Column-->
                                
                                <!--Service Column-->
                                <div class="column service-column col-md-6 col-sm-12 col-xs-12">
                                    <h3> <?php echo $AL[2] ?> </h3>
                                    <div class="text"><?php echo $AD[2] ?> </div>
                                </div>
                                
                            </div>
                            
                            <figure class="man-image wow bounceInUp" data-wow-delay="500ms" data-wow-duration="1500ms"><img "img/resource/man-image-3.png" alt=""></figure>
                            
                        </div>
                    </div>
            </section>
        </div>
    </div>
</div>
<br><br><br>

    <!--Default Intro Section-->
    <?php include('none.php') ?>

    <br>
    
    <!--Main Footer-->

    <?php include('php/secction/footer.php') ?>
